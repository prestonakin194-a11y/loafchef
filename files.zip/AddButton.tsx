"use client";
import { useState } from "react";
import { useCart } from "./CartContext";

export default function AddButton({ product }: { product: { id: string; name: string; price: number; emoji: string; soldOut?: boolean } }) {
  const { add } = useCart();
  const [added, setAdded] = useState(false);

  if (product.soldOut) {
    return <span className="text-xs opacity-50 border border-line px-3 py-1.5 rounded-sm">Sold out</span>;
  }

  return (
    <button
      onClick={() => { add({ productId: product.id, name: product.name, price: product.price, emoji: product.emoji }); setAdded(true); setTimeout(() => setAdded(false), 1200); }}
      className="text-xs bg-crust text-flour px-3 py-1.5 rounded-sm font-medium"
    >
      {added ? "Added ✓" : "Add to cart"}
    </button>
  );
}
