import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { money } from "@/lib/config";
import AddButton from "@/components/AddButton";

export default async function Home() {
  const featured = await prisma.product.findMany({ where: { active: true }, take: 4, orderBy: { id: "asc" } });

  return (
    <main>
      <header className="max-w-5xl mx-auto px-6 pt-16 pb-12 border-b border-line">
        <div className="text-ember text-sm mb-3 font-medium">Baked daily, from scratch</div>
        <h1 className="font-serif text-4xl md:text-6xl leading-tight max-w-xl mb-5">
          Real bread, real butter, no shortcuts.
        </h1>
        <p className="max-w-md opacity-80 mb-7">
          Order sourdough, pastries and cakes for pickup or delivery — or ask us to build something custom for your next celebration.
        </p>
        <div className="flex gap-3 flex-wrap">
          <Link href="/menu" className="bg-crust text-flour px-6 py-3 rounded-sm font-medium">Order Now</Link>
          <Link href="/custom" className="border border-crust px-6 py-3 rounded-sm font-medium">Custom Cakes &amp; Catering</Link>
        </div>
      </header>

      <section className="max-w-5xl mx-auto px-6 py-16 border-b border-line">
        <div className="flex items-baseline justify-between mb-8">
          <h2 className="font-serif text-2xl">Today's favorites</h2>
          <Link href="/menu" className="text-sm text-ember font-medium">See full menu →</Link>
        </div>
        <div className="grid sm:grid-cols-2 gap-5">
          {featured.map((p) => (
            <div key={p.id} className="border border-line p-5 flex gap-4">
              <div className="text-3xl">{p.emoji}</div>
              <div className="flex-1">
                <div className="font-semibold">{p.name}</div>
                <p className="text-sm opacity-70 mt-1">{p.description}</p>
                <div className="flex items-center justify-between mt-3">
                  <span className="font-serif">{money(p.price)}</span>
                  <AddButton product={p} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="border-t border-crust pt-4">
            <h3 className="font-semibold mb-1">Pickup or delivery</h3>
            <p className="text-sm opacity-75">Choose a time slot that works for you — we bake to order, not to a shelf.</p>
          </div>
          <div className="border-t border-crust pt-4">
            <h3 className="font-semibold mb-1">Custom cakes</h3>
            <p className="text-sm opacity-75">Tell us the occasion and flavors — we'll quote you within a day or two.</p>
          </div>
          <div className="border-t border-crust pt-4">
            <h3 className="font-semibold mb-1">Catering</h3>
            <p className="text-sm opacity-75">Pastry boxes and bread spreads for events of any size.</p>
          </div>
        </div>
      </section>
    </main>
  );
}
