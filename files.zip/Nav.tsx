"use client";
import Link from "next/link";
import { useCart } from "./CartContext";
import { SHOP } from "@/lib/config";

export default function Nav() {
  const { count } = useCart();
  return (
    <nav className="sticky top-0 z-50 bg-flour border-b border-line">
      <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link href="/" className="font-serif text-xl font-semibold">{SHOP.name}<span className="text-ember">.</span></Link>
        <div className="hidden md:flex gap-7 text-sm">
          <Link href="/menu" className="opacity-75 hover:opacity-100">Menu</Link>
          <Link href="/custom" className="opacity-75 hover:opacity-100">Custom Cakes &amp; Catering</Link>
          <Link href="/about" className="opacity-75 hover:opacity-100">About</Link>
        </div>
        <Link href="/cart" className="bg-crust text-flour px-4 py-2 text-sm rounded-sm">
          Cart {count > 0 && <span>({count})</span>}
        </Link>
      </div>
    </nav>
  );
}
