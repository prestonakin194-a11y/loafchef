"use server";
import { prisma } from "@/lib/prisma";
import { loginAdmin, logoutAdmin } from "@/lib/admin";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";

export async function loginAction(formData: FormData) {
  const password = String(formData.get("password") || "");
  if (!loginAdmin(password)) redirect("/admin/login?error=1");
  redirect("/admin");
}

export async function logoutAction() {
  logoutAdmin();
  redirect("/admin/login");
}

export async function toggleSoldOut(id: string, soldOut: boolean) {
  await prisma.product.update({ where: { id }, data: { soldOut } });
  revalidatePath("/admin/products");
  revalidatePath("/menu");
  revalidatePath("/");
}

export async function toggleActive(id: string, active: boolean) {
  await prisma.product.update({ where: { id }, data: { active } });
  revalidatePath("/admin/products");
  revalidatePath("/menu");
  revalidatePath("/");
}

export async function updatePrice(id: string, priceDollars: string) {
  const price = Math.round(Number(priceDollars) * 100);
  if (!Number.isFinite(price) || price <= 0) return;
  await prisma.product.update({ where: { id }, data: { price } });
  revalidatePath("/admin/products");
  revalidatePath("/menu");
  revalidatePath("/");
}

export async function addProduct(formData: FormData) {
  const name = String(formData.get("name") || "").trim();
  const category = String(formData.get("category") || "Loaves");
  const description = String(formData.get("description") || "");
  const price = Math.round(Number(formData.get("price") || 0) * 100);
  const emoji = String(formData.get("emoji") || "🍞");
  if (!name || price <= 0) return;
  await prisma.product.create({ data: { name, category, description, price, emoji } });
  revalidatePath("/admin/products");
  revalidatePath("/menu");
  revalidatePath("/");
}

export async function updateOrderStatus(id: string, status: string) {
  await prisma.order.update({ where: { id }, data: { status } });
  revalidatePath("/admin");
}

export async function submitQuote(id: string, quoteDollars: string, note: string) {
  const quote = Math.round(Number(quoteDollars) * 100);
  await prisma.customRequest.update({ where: { id }, data: { quote: quote || null, quoteNote: note, status: "QUOTED" } });
  revalidatePath("/admin/requests");
}

export async function setRequestStatus(id: string, status: string) {
  await prisma.customRequest.update({ where: { id }, data: { status } });
  revalidatePath("/admin/requests");
}
