import Link from "next/link";
import { logoutAction } from "@/app/admin/actions";

export default function AdminNav({ active }: { active: "orders" | "products" | "requests" }) {
  const tabs = [
    { id: "orders", label: "Orders", href: "/admin" },
    { id: "products", label: "Menu", href: "/admin/products" },
    { id: "requests", label: "Requests", href: "/admin/requests" }
  ] as const;
  return (
    <div className="border-b border-line mb-8">
      <div className="max-w-5xl mx-auto px-6 flex items-center justify-between">
        <div className="flex gap-6">
          {tabs.map((t) => (
            <Link key={t.id} href={t.href} className={`py-4 text-sm border-b-2 ${active === t.id ? "border-crust font-semibold" : "border-transparent opacity-70"}`}>
              {t.label}
            </Link>
          ))}
        </div>
        <form action={logoutAction}><button className="text-sm opacity-60 hover:opacity-100">Sign out</button></form>
      </div>
    </div>
  );
}
