"use client";
import { useState } from "react";
import { toggleSoldOut, toggleActive, updatePrice } from "@/app/admin/actions";
import { money } from "@/lib/config";

export default function ProductRow({ product }: { product: { id: string; name: string; category: string; price: number; soldOut: boolean; active: boolean } }) {
  const [price, setPrice] = useState((product.price / 100).toFixed(2));

  return (
    <div className="flex flex-wrap items-center gap-4 py-3 border-b border-line text-sm">
      <div className="flex-1 min-w-[160px]">
        <div className="font-semibold">{product.name}</div>
        <div className="opacity-60">{product.category}</div>
      </div>
      <div className="flex items-center gap-1">
        <span className="opacity-60">$</span>
        <input value={price} onChange={(e) => setPrice(e.target.value)} onBlur={() => updatePrice(product.id, price)}
          className="w-20 border border-line p-1.5 bg-transparent" />
      </div>
      <label className="flex items-center gap-2">
        <input type="checkbox" checked={product.soldOut} onChange={(e) => toggleSoldOut(product.id, e.target.checked)} />
        Sold out today
      </label>
      <label className="flex items-center gap-2">
        <input type="checkbox" checked={product.active} onChange={(e) => toggleActive(product.id, e.target.checked)} />
        On menu
      </label>
    </div>
  );
}
