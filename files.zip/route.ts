import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { SHOP } from "@/lib/config";
import { availableDates } from "@/lib/slots";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const date = new URL(req.url).searchParams.get("date");
  const dates = availableDates();
  if (!date) return NextResponse.json({ dates });
  if (!dates.includes(date)) return NextResponse.json({ dates, slots: [] });

  const orders = await prisma.order.groupBy({
    by: ["slot"],
    where: { date, status: { not: "CANCELLED" } },
    _count: { _all: true }
  });
  const used = Object.fromEntries(orders.map((o) => [o.slot, o._count._all]));
  const slots = SHOP.slots.map((s) => ({ slot: s, remaining: Math.max(0, SHOP.slotCapacity - (used[s] || 0)) }));
  return NextResponse.json({ dates, slots });
}
