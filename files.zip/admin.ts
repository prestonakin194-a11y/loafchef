import { cookies } from "next/headers";
import { createHmac, timingSafeEqual } from "crypto";

const COOKIE = "lc_admin";
const sign = () => createHmac("sha256", process.env.ADMIN_SECRET || "dev-secret").update("admin").digest("hex");

export function isAdmin(): boolean {
  const v = cookies().get(COOKIE)?.value;
  if (!v) return false;
  const a = Buffer.from(v), b = Buffer.from(sign());
  return a.length === b.length && timingSafeEqual(a, b);
}

export function loginAdmin(password: string): boolean {
  if (!process.env.ADMIN_PASSWORD || password !== process.env.ADMIN_PASSWORD) return false;
  cookies().set(COOKIE, sign(), { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 60 * 60 * 24 * 7, path: "/" });
  return true;
}

export function logoutAdmin() {
  cookies().delete(COOKIE);
}
