import Stripe from "stripe";
export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, { apiVersion: "2024-06-20" });
export const APP_URL = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
