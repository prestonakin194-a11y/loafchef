import { SHOP } from "./config";

export function toISO(d: Date) {
  const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, "0"), day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function availableDates(): string[] {
  const out: string[] = [];
  for (let i = SHOP.minDaysAhead; i <= SHOP.maxDaysAhead; i++) {
    const d = new Date();
    d.setDate(d.getDate() + i);
    if (SHOP.openDays.includes(d.getDay())) out.push(toISO(d));
  }
  return out;
}
