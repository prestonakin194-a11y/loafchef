import { NextResponse } from "next/server";
import Stripe from "stripe";
import { stripe } from "@/lib/stripe";
import { prisma } from "@/lib/prisma";
import { confirmOrder } from "@/lib/orders";

export async function POST(req: Request) {
  const body = await req.text();
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body, req.headers.get("stripe-signature") as string, process.env.STRIPE_WEBHOOK_SECRET as string);
  } catch (err: any) {
    return NextResponse.json({ error: `Webhook error: ${err.message}` }, { status: 400 });
  }

  const session = event.data.object as Stripe.Checkout.Session;
  const orderId = session.metadata?.orderId;

  if (event.type === "checkout.session.completed" && orderId) await confirmOrder(orderId);
  if (event.type === "checkout.session.expired" && orderId) {
    await prisma.order.updateMany({ where: { id: orderId, paymentStatus: "UNPAID" }, data: { status: "CANCELLED" } });
  }
  return NextResponse.json({ received: true });
}
