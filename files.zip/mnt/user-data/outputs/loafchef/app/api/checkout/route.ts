import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { stripe, APP_URL } from "@/lib/stripe";
import { SHOP } from "@/lib/config";
import { availableDates } from "@/lib/slots";

export async function POST(req: Request) {
  const b = await req.json();
  const { items, name, email, phone, fulfillment, date, slot, address, notes } = b;

  if (!Array.isArray(items) || items.length === 0) return NextResponse.json({ error: "Your cart is empty." }, { status: 400 });
  if (!name || !email || !phone) return NextResponse.json({ error: "Name, email and phone are required." }, { status: 400 });
  if (!["PICKUP", "DELIVERY"].includes(fulfillment)) return NextResponse.json({ error: "Choose pickup or delivery." }, { status: 400 });
  if (fulfillment === "DELIVERY" && !address) return NextResponse.json({ error: "Delivery address is required." }, { status: 400 });
  if (!availableDates().includes(date) || !SHOP.slots.includes(slot)) return NextResponse.json({ error: "Pick a valid date and time." }, { status: 400 });

  // Prices always come from the database, never from the browser.
  const ids = items.map((i: any) => i.productId);
  const products = await prisma.product.findMany({ where: { id: { in: ids } } });
  const lines: { productId: string; name: string; unitPrice: number; qty: number }[] = [];
  for (const i of items) {
    const p = products.find((x) => x.id === i.productId);
    const qty = Math.floor(Number(i.qty));
    if (!p || !p.active) return NextResponse.json({ error: "An item in your cart is no longer available." }, { status: 400 });
    if (p.soldOut) return NextResponse.json({ error: `${p.name} is sold out.` }, { status: 400 });
    if (!(qty >= 1 && qty <= 50)) return NextResponse.json({ error: "Invalid quantity." }, { status: 400 });
    lines.push({ productId: p.id, name: p.name, unitPrice: p.price, qty });
  }

  const subtotal = lines.reduce((s, l) => s + l.unitPrice * l.qty, 0);
  if (fulfillment === "DELIVERY" && subtotal < SHOP.deliveryMin)
    return NextResponse.json({ error: `Delivery minimum is $${(SHOP.deliveryMin / 100).toFixed(0)}.` }, { status: 400 });
  const deliveryFee = fulfillment === "DELIVERY" ? SHOP.deliveryFee : 0;

  const taken = await prisma.order.count({ where: { date, slot, status: { not: "CANCELLED" } } });
  if (taken >= SHOP.slotCapacity) return NextResponse.json({ error: "That time slot just filled up. Pick another." }, { status: 409 });

  const order = await prisma.order.create({
    data: {
      name, email, phone, fulfillment, date, slot, address: address || null, notes: notes || null,
      subtotal, deliveryFee, total: subtotal + deliveryFee,
      items: { create: lines }
    }
  });

  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    customer_email: email,
    line_items: [
      ...lines.map((l) => ({
        quantity: l.qty,
        price_data: { currency: "usd", unit_amount: l.unitPrice, product_data: { name: l.name } }
      })),
      ...(deliveryFee ? [{ quantity: 1, price_data: { currency: "usd", unit_amount: deliveryFee, product_data: { name: "Delivery fee" } } }] : [])
    ],
    metadata: { orderId: order.id },
    expires_at: Math.floor(Date.now() / 1000) + 30 * 60,
    success_url: `${APP_URL}/order/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${APP_URL}/cart?cancelled=1`
  });

  await prisma.order.update({ where: { id: order.id }, data: { stripeSessionId: session.id } });
  return NextResponse.json({ url: session.url });
}
