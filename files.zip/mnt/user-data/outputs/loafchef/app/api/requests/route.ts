import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { sendEmail } from "@/lib/email";
import { SHOP } from "@/lib/config";

export async function POST(req: Request) {
  const b = await req.json();
  if (!["CAKE", "CATERING"].includes(b.type) || !b.name || !b.email || !b.phone || !b.eventDate || !b.details) {
    return NextResponse.json({ error: "Please fill in all required fields." }, { status: 400 });
  }
  const earliest = new Date();
  earliest.setDate(earliest.getDate() + SHOP.customLeadDays);
  if (new Date(b.eventDate) < earliest) {
    return NextResponse.json({ error: `Custom orders need at least ${SHOP.customLeadDays} days' notice.` }, { status: 400 });
  }
  await prisma.customRequest.create({
    data: {
      type: b.type, name: b.name, email: b.email, phone: b.phone, eventDate: b.eventDate,
      guests: b.guests ? Number(b.guests) : null, budget: b.budget || null, details: b.details, referenceUrl: b.referenceUrl || null
    }
  });
  await sendEmail(b.email, `We got your ${SHOP.name} request`, `<p>Hi ${b.name}, thanks! We'll reply with a quote within 1–2 days.</p>`);
  if (process.env.OWNER_EMAIL) await sendEmail(process.env.OWNER_EMAIL, `New ${b.type} request from ${b.name}`, `<p>${b.details}</p><p>${b.email} · ${b.phone} · ${b.eventDate}</p>`);
  return NextResponse.json({ ok: true });
}
