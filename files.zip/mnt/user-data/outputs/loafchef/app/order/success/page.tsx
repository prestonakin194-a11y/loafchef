import { stripe } from "@/lib/stripe";
import { prisma } from "@/lib/prisma";
import { confirmOrder } from "@/lib/orders";
import { money, slotLabel, SHOP } from "@/lib/config";
import { notFound } from "next/navigation";
import ClearCart from "./ClearCart";

export default async function OrderSuccess({ searchParams }: { searchParams: { session_id?: string } }) {
  const sessionId = searchParams.session_id;
  if (!sessionId) return notFound();

  const checkoutSession = await stripe.checkout.sessions.retrieve(sessionId);
  const orderId = checkoutSession.metadata?.orderId;
  if (!orderId) return notFound();

  // Fallback confirmation in case the webhook hasn't landed yet — the webhook stays the source of truth.
  if (checkoutSession.payment_status === "paid") await confirmOrder(orderId);

  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { items: true } });
  if (!order) return notFound();
  const paid = order.paymentStatus === "PAID";

  return (
    <main className="max-w-md mx-auto px-6 py-24 text-center">
      {paid && <ClearCart />}
      <div className="w-14 h-14 rounded-full bg-crust text-flour flex items-center justify-center mx-auto mb-5 text-xl">{paid ? "✓" : "…"}</div>
      <h1 className="font-serif text-2xl mb-2">{paid ? "Order confirmed" : "Finishing up…"}</h1>
      <p className="opacity-75 mb-6">
        {paid
          ? `${money(order.total)} charged. ${order.fulfillment === "DELIVERY" ? "We'll deliver to " + order.address : "Ready for pickup at " + SHOP.address} on ${order.date} at ${slotLabel(order.slot)}.`
          : "We're confirming your payment — refresh in a moment if this doesn't update."}
      </p>
      {paid && (
        <ul className="text-sm text-left border border-line p-4 mb-6">
          {order.items.map((i) => <li key={i.id} className="flex justify-between py-1"><span>{i.qty} × {i.name}</span><span>{money(i.unitPrice * i.qty)}</span></li>)}
        </ul>
      )}
    </main>
  );
}
