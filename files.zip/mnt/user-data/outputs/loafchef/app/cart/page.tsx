"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useCart } from "@/components/CartContext";
import { money } from "@/lib/config";

type SlotInfo = { slot: string; remaining: number };

function slotLabel(s: string) {
  const [h, m] = s.split(":").map(Number);
  return `${h % 12 || 12}:${String(m).padStart(2, "0")} ${h >= 12 ? "PM" : "AM"}`;
}

export default function CartPage() {
  const { items, setQty, remove, subtotal } = useCart();
  const [dates, setDates] = useState<string[]>([]);
  const [date, setDate] = useState("");
  const [slots, setSlots] = useState<SlotInfo[]>([]);
  const [slot, setSlot] = useState("");
  const [fulfillment, setFulfillment] = useState<"PICKUP" | "DELIVERY">("PICKUP");
  const [form, setForm] = useState({ name: "", email: "", phone: "", address: "", notes: "" });
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => { fetch("/api/slots").then((r) => r.json()).then((d) => setDates(d.dates)); }, []);
  useEffect(() => {
    if (!date) return setSlots([]);
    fetch(`/api/slots?date=${date}`).then((r) => r.json()).then((d) => setSlots(d.slots || []));
    setSlot("");
  }, [date]);

  const deliveryFee = fulfillment === "DELIVERY" ? 600 : 0;
  const total = subtotal + deliveryFee;

  async function checkout() {
    setError("");
    if (items.length === 0) return setError("Your cart is empty.");
    if (!date || !slot) return setError("Pick a date and time.");
    if (!form.name || !form.email || !form.phone) return setError("Name, email and phone are required.");
    if (fulfillment === "DELIVERY" && !form.address) return setError("Delivery address is required.");

    setSubmitting(true);
    const res = await fetch("/api/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        items: items.map((i) => ({ productId: i.productId, qty: i.qty })),
        fulfillment, date, slot, ...form
      })
    });
    const data = await res.json();
    setSubmitting(false);
    if (!res.ok) return setError(data.error || "Something went wrong.");
    window.location.href = data.url;
  }

  return (
    <main className="max-w-3xl mx-auto px-6 py-12">
      <h1 className="font-serif text-3xl mb-8">Your cart</h1>

      {items.length === 0 ? (
        <p className="opacity-70">Your cart is empty. <Link href="/menu" className="text-ember font-medium">Browse the menu →</Link></p>
      ) : (
        <>
          <div className="border-t border-ink">
            {items.map((i) => (
              <div key={i.productId} className="flex items-center gap-4 py-4 border-b border-line">
                <div className="text-2xl">{i.emoji}</div>
                <div className="flex-1">
                  <div className="font-semibold">{i.name}</div>
                  <div className="text-sm opacity-65">{money(i.price)} each</div>
                </div>
                <input type="number" min={0} max={50} value={i.qty} onChange={(e) => setQty(i.productId, Number(e.target.value))}
                  className="w-16 border border-line p-2 text-center bg-transparent" />
                <div className="w-20 text-right font-serif">{money(i.price * i.qty)}</div>
                <button onClick={() => remove(i.productId)} className="text-sm opacity-50 hover:opacity-100">✕</button>
              </div>
            ))}
          </div>

          <div className="mt-8 border border-line p-6">
            <h2 className="font-serif text-xl mb-5">Pickup or delivery</h2>
            <div className="flex gap-3 mb-5">
              {(["PICKUP", "DELIVERY"] as const).map((f) => (
                <button key={f} onClick={() => setFulfillment(f)}
                  className={`flex-1 border p-3 text-sm ${fulfillment === f ? "border-crust bg-wheat" : "border-line"}`}>
                  {f === "PICKUP" ? "Pickup (free)" : "Delivery (+$6.00)"}
                </button>
              ))}
            </div>

            <div className="grid sm:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm opacity-70 mb-1">Date</label>
                <select value={date} onChange={(e) => setDate(e.target.value)} className="w-full border border-line p-3 bg-transparent">
                  <option value="">Choose a date</option>
                  {dates.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm opacity-70 mb-1">Time</label>
                <select value={slot} onChange={(e) => setSlot(e.target.value)} disabled={!date} className="w-full border border-line p-3 bg-transparent disabled:opacity-40">
                  <option value="">{date ? "Choose a time" : "Pick a date first"}</option>
                  {slots.map((s) => (
                    <option key={s.slot} value={s.slot} disabled={s.remaining <= 0}>
                      {slotLabel(s.slot)} {s.remaining <= 0 ? "— full" : `— ${s.remaining} left`}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {fulfillment === "DELIVERY" && (
              <div className="mb-4">
                <label className="block text-sm opacity-70 mb-1">Delivery address</label>
                <input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })}
                  placeholder="123 Maple St" className="w-full border border-line p-3 bg-transparent" />
              </div>
            )}

            <div className="grid sm:grid-cols-2 gap-4 mb-4">
              <div><label className="block text-sm opacity-70 mb-1">Name</label>
                <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full border border-line p-3 bg-transparent" /></div>
              <div><label className="block text-sm opacity-70 mb-1">Phone</label>
                <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full border border-line p-3 bg-transparent" /></div>
            </div>
            <div className="mb-4">
              <label className="block text-sm opacity-70 mb-1">Email</label>
              <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full border border-line p-3 bg-transparent" />
            </div>
            <div className="mb-6">
              <label className="block text-sm opacity-70 mb-1">Notes (optional)</label>
              <input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Allergies, gate code, etc." className="w-full border border-line p-3 bg-transparent" />
            </div>

            <div className="border-t border-line pt-4 mb-6 text-sm">
              <div className="flex justify-between py-1"><span>Subtotal</span><span>{money(subtotal)}</span></div>
              {deliveryFee > 0 && <div className="flex justify-between py-1"><span>Delivery</span><span>{money(deliveryFee)}</span></div>}
              <div className="flex justify-between py-1 font-semibold text-base"><span>Total</span><span>{money(total)}</span></div>
            </div>

            {error && <p className="text-sm mb-4" style={{ color: "#b03a2e" }}>{error}</p>}
            <button onClick={checkout} disabled={submitting} className="w-full bg-crust text-flour py-3 rounded-sm font-medium disabled:opacity-50">
              {submitting ? "Redirecting to payment…" : `Pay ${money(total)}`}
            </button>
          </div>
        </>
      )}
    </main>
  );
}
