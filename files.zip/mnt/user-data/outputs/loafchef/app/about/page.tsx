import { SHOP } from "@/lib/config";

export default function About() {
  return (
    <main className="max-w-3xl mx-auto px-6 py-16">
      <h1 className="font-serif text-3xl mb-6">About {SHOP.name}</h1>
      <p className="opacity-80 mb-4 max-w-xl">
        [Replace this with your real story — how the bakery started, what you bake and why,
        who's behind the counter. A paragraph or two is plenty.]
      </p>
      <div className="grid sm:grid-cols-2 gap-8 mt-10 border-t border-line pt-8">
        <div>
          <h2 className="font-semibold mb-2">Visit us</h2>
          <p className="text-sm opacity-75">{SHOP.address}</p>
          <p className="text-sm opacity-75">{SHOP.hours}</p>
        </div>
        <div>
          <h2 className="font-semibold mb-2">Get in touch</h2>
          <p className="text-sm opacity-75">{SHOP.phone}</p>
          <p className="text-sm opacity-75">{SHOP.email}</p>
          <p className="text-sm opacity-75">{SHOP.instagram}</p>
        </div>
      </div>
    </main>
  );
}
