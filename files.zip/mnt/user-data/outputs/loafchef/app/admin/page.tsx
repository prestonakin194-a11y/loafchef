import { redirect } from "next/navigation";
import { isAdmin } from "@/lib/admin";
import { prisma } from "@/lib/prisma";
import { money, slotLabel } from "@/lib/config";
import AdminNav from "@/components/AdminNav";
import OrderStatusSelect from "@/components/OrderStatusSelect";

export default async function AdminOrders() {
  if (!isAdmin()) redirect("/admin/login");

  const orders = await prisma.order.findMany({
    where: { paymentStatus: "PAID" },
    include: { items: true },
    orderBy: [{ date: "asc" }, { slot: "asc" }]
  });

  return (
    <main>
      <AdminNav active="orders" />
      <div className="max-w-5xl mx-auto px-6 pb-16">
        <h1 className="font-serif text-3xl mb-2">Orders</h1>
        <p className="opacity-65 text-sm mb-8">{orders.length} paid order{orders.length !== 1 ? "s" : ""}.</p>

        {orders.length === 0 && <p className="opacity-60">No paid orders yet.</p>}

        <div className="space-y-4">
          {orders.map((o) => (
            <div key={o.id} className="border border-line p-5">
              <div className="flex flex-wrap justify-between gap-2 mb-3">
                <div>
                  <div className="font-semibold">{o.name} — {o.fulfillment === "DELIVERY" ? "Delivery" : "Pickup"}</div>
                  <div className="text-sm opacity-65">{o.date} · {slotLabel(o.slot)} · {o.phone} · {o.email}</div>
                  {o.address && <div className="text-sm opacity-65">{o.address}</div>}
                  {o.notes && <div className="text-sm opacity-65 italic">Note: {o.notes}</div>}
                </div>
                <OrderStatusSelect orderId={o.id} status={o.status} />
              </div>
              <ul className="text-sm border-t border-line pt-3">
                {o.items.map((i) => <li key={i.id} className="flex justify-between py-1"><span>{i.qty} × {i.name}</span><span>{money(i.unitPrice * i.qty)}</span></li>)}
              </ul>
              <div className="text-right font-semibold mt-2">{money(o.total)}</div>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
