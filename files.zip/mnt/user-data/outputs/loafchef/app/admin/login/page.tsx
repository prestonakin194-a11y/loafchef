import { loginAction } from "../actions";

export default function AdminLogin({ searchParams }: { searchParams: { error?: string } }) {
  return (
    <main className="max-w-sm mx-auto px-6 py-24">
      <h1 className="font-serif text-3xl mb-8">Baker sign in</h1>
      <form action={loginAction}>
        <label className="block text-sm opacity-70 mb-1">Password</label>
        <input type="password" name="password" required autoFocus className="w-full border border-line p-3 bg-transparent mb-4" />
        {searchParams.error && <p className="text-sm mb-4" style={{ color: "#b03a2e" }}>Wrong password.</p>}
        <button className="w-full bg-crust text-flour py-3 rounded-sm font-medium">Sign in</button>
      </form>
    </main>
  );
}
