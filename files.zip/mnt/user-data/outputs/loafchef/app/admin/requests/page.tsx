import { redirect } from "next/navigation";
import { isAdmin } from "@/lib/admin";
import { prisma } from "@/lib/prisma";
import { money } from "@/lib/config";
import AdminNav from "@/components/AdminNav";
import QuoteForm from "@/components/QuoteForm";

export default async function AdminRequests() {
  if (!isAdmin()) redirect("/admin/login");
  const requests = await prisma.customRequest.findMany({ orderBy: { createdAt: "desc" } });

  return (
    <main>
      <AdminNav active="requests" />
      <div className="max-w-3xl mx-auto px-6 pb-16">
        <h1 className="font-serif text-3xl mb-2">Custom cake &amp; catering requests</h1>
        <p className="opacity-65 text-sm mb-8">{requests.length} request{requests.length !== 1 ? "s" : ""}. Sending a quote emails the customer the amount and your note.</p>

        {requests.length === 0 && <p className="opacity-60">No requests yet.</p>}

        <div className="space-y-4">
          {requests.map((r) => (
            <div key={r.id} className="border border-line p-5">
              <div className="flex flex-wrap justify-between gap-2">
                <div>
                  <div className="font-semibold">{r.name} — {r.type === "CAKE" ? "Custom cake" : "Catering"}</div>
                  <div className="text-sm opacity-65">{r.email} · {r.phone} · Event: {r.eventDate}{r.guests ? ` · ${r.guests} guests` : ""}</div>
                  {r.budget && <div className="text-sm opacity-65">Budget: {r.budget}</div>}
                </div>
                <span className="text-xs border border-line px-2 py-1 h-fit rounded-sm">{r.status}</span>
              </div>
              <p className="text-sm mt-3 opacity-85">{r.details}</p>
              {r.quote && <p className="text-sm mt-2 font-medium">Quoted: {money(r.quote)} {r.quoteNote && `— ${r.quoteNote}`}</p>}
              <QuoteForm id={r.id} quote={r.quote} quoteNote={r.quoteNote} />
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
