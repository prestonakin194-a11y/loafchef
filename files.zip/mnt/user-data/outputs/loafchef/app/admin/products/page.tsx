import { redirect } from "next/navigation";
import { isAdmin } from "@/lib/admin";
import { prisma } from "@/lib/prisma";
import AdminNav from "@/components/AdminNav";
import ProductRow from "@/components/ProductRow";
import { addProduct } from "../actions";

export default async function AdminProducts() {
  if (!isAdmin()) redirect("/admin/login");
  const products = await prisma.product.findMany({ orderBy: { category: "asc" } });

  return (
    <main>
      <AdminNav active="products" />
      <div className="max-w-3xl mx-auto px-6 pb-16">
        <h1 className="font-serif text-3xl mb-2">Menu</h1>
        <p className="opacity-65 text-sm mb-6">
          Toggle "Sold out today" when you run out — it comes back automatically the next day when you reset it here.
          Uncheck "On menu" to hide a seasonal item entirely.
        </p>

        <div>
          {products.map((p) => <ProductRow key={p.id} product={p} />)}
        </div>

        <details className="mt-10 border border-line p-5">
          <summary className="cursor-pointer font-semibold">Add a new item</summary>
          <form action={addProduct} className="mt-4 grid sm:grid-cols-2 gap-4">
            <div><label className="block text-sm opacity-70 mb-1">Name</label><input name="name" required className="w-full border border-line p-2 bg-transparent" /></div>
            <div>
              <label className="block text-sm opacity-70 mb-1">Category</label>
              <select name="category" className="w-full border border-line p-2 bg-transparent">
                <option>Loaves</option><option>Pastries</option><option>Cookies</option><option>Cakes</option>
              </select>
            </div>
            <div className="sm:col-span-2"><label className="block text-sm opacity-70 mb-1">Description</label><input name="description" className="w-full border border-line p-2 bg-transparent" /></div>
            <div><label className="block text-sm opacity-70 mb-1">Price ($)</label><input name="price" type="number" step="0.01" required className="w-full border border-line p-2 bg-transparent" /></div>
            <div><label className="block text-sm opacity-70 mb-1">Emoji</label><input name="emoji" defaultValue="🍞" className="w-full border border-line p-2 bg-transparent" /></div>
            <button className="sm:col-span-2 bg-crust text-flour py-2.5 rounded-sm font-medium">Add item</button>
          </form>
        </details>
      </div>
    </main>
  );
}
