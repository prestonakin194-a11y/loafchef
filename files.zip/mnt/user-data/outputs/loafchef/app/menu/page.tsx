import { prisma } from "@/lib/prisma";
import { money } from "@/lib/config";
import AddButton from "@/components/AddButton";

const CATEGORY_ORDER = ["Loaves", "Pastries", "Cookies", "Cakes"];

export default async function Menu() {
  const products = await prisma.product.findMany({ where: { active: true } });
  const byCategory = CATEGORY_ORDER.map((cat) => ({ cat, items: products.filter((p) => p.category === cat) })).filter((g) => g.items.length);

  return (
    <main className="max-w-5xl mx-auto px-6">
      <div className="py-10 border-b border-line">
        <h1 className="font-serif text-3xl">Menu</h1>
        <p className="opacity-70 mt-2">Everything's baked fresh — sold-out items reopen the next baking day.</p>
      </div>
      {byCategory.map(({ cat, items }) => (
        <section key={cat} className="py-10 border-b border-line">
          <h2 className="font-serif text-2xl mb-6">{cat}</h2>
          <div className="grid sm:grid-cols-2 gap-5">
            {items.map((p) => (
              <div key={p.id} className="border border-line p-5 flex gap-4">
                <div className="text-3xl">{p.emoji}</div>
                <div className="flex-1">
                  <div className="font-semibold">{p.name}</div>
                  <p className="text-sm opacity-70 mt-1">{p.description}</p>
                  <div className="flex items-center justify-between mt-3">
                    <span className="font-serif">{money(p.price)}</span>
                    <AddButton product={p} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      ))}
    </main>
  );
}
