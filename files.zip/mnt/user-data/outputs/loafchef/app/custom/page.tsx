"use client";
import { useState } from "react";
import { SHOP } from "@/lib/config";

export default function CustomPage() {
  const [type, setType] = useState<"CAKE" | "CATERING">("CAKE");
  const [form, setForm] = useState({ name: "", email: "", phone: "", eventDate: "", guests: "", budget: "", details: "" });
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(""); setSubmitting(true);
    const res = await fetch("/api/requests", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type, ...form }) });
    setSubmitting(false);
    if (!res.ok) { const d = await res.json(); setError(d.error || "Something went wrong."); return; }
    setDone(true);
  }

  if (done) {
    return (
      <main className="max-w-md mx-auto px-6 py-24 text-center">
        <div className="w-14 h-14 rounded-full bg-crust text-flour flex items-center justify-center mx-auto mb-5 text-xl">✓</div>
        <h1 className="font-serif text-2xl mb-2">Request sent</h1>
        <p className="opacity-75">We'll follow up by email with a quote — usually within a day or two.</p>
      </main>
    );
  }

  return (
    <main className="max-w-lg mx-auto px-6 py-16">
      <h1 className="font-serif text-3xl mb-2">Custom cakes &amp; catering</h1>
      <p className="opacity-70 mb-8 text-sm">Tell us what you need and we'll send a quote. Please allow at least {SHOP.customLeadDays} days' notice.</p>

      <div className="flex gap-3 mb-6">
        {(["CAKE", "CATERING"] as const).map((t) => (
          <button key={t} type="button" onClick={() => setType(t)} className={`flex-1 border p-3 text-sm ${type === t ? "border-crust bg-wheat" : "border-line"}`}>
            {t === "CAKE" ? "Custom cake" : "Catering / event"}
          </button>
        ))}
      </div>

      <form onSubmit={submit}>
        <div className="grid sm:grid-cols-2 gap-4 mb-4">
          <div><label className="block text-sm opacity-70 mb-1">Name</label>
            <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full border border-line p-3 bg-transparent" /></div>
          <div><label className="block text-sm opacity-70 mb-1">Phone</label>
            <input required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full border border-line p-3 bg-transparent" /></div>
        </div>
        <div className="mb-4">
          <label className="block text-sm opacity-70 mb-1">Email</label>
          <input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full border border-line p-3 bg-transparent" />
        </div>
        <div className="grid sm:grid-cols-2 gap-4 mb-4">
          <div><label className="block text-sm opacity-70 mb-1">Event date</label>
            <input required type="date" value={form.eventDate} onChange={(e) => setForm({ ...form, eventDate: e.target.value })} className="w-full border border-line p-3 bg-transparent" /></div>
          <div><label className="block text-sm opacity-70 mb-1"># of guests (optional)</label>
            <input type="number" min={1} value={form.guests} onChange={(e) => setForm({ ...form, guests: e.target.value })} className="w-full border border-line p-3 bg-transparent" /></div>
        </div>
        <div className="mb-4">
          <label className="block text-sm opacity-70 mb-1">Budget (optional)</label>
          <input value={form.budget} onChange={(e) => setForm({ ...form, budget: e.target.value })} placeholder="e.g. $150–200" className="w-full border border-line p-3 bg-transparent" />
        </div>
        <div className="mb-6">
          <label className="block text-sm opacity-70 mb-1">{type === "CAKE" ? "Flavor, size, design, dietary needs" : "What you need — items, quantities, dietary needs"}</label>
          <textarea required rows={5} value={form.details} onChange={(e) => setForm({ ...form, details: e.target.value })} className="w-full border border-line p-3 bg-transparent" />
        </div>
        {error && <p className="text-sm mb-4" style={{ color: "#b03a2e" }}>{error}</p>}
        <button disabled={submitting} className="w-full bg-crust text-flour py-3 rounded-sm font-medium disabled:opacity-50">
          {submitting ? "Sending…" : "Send request"}
        </button>
      </form>
    </main>
  );
}
