import type { Config } from "tailwindcss";
export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: { flour: "#F7F1E5", crust: "#4A2E1C", ember: "#C8501F", wheat: "#E8D5B0", line: "#DDD0B8", crumb: "#EFE5D0" },
      fontFamily: { serif: ["Fraunces", "Georgia", "serif"], sans: ["DM Sans", "system-ui", "sans-serif"] }
    }
  },
  plugins: []
} satisfies Config;
