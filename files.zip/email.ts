// Sends email through Resend's HTTP API. No-ops if RESEND_API_KEY isn't set.
export async function sendEmail(to: string, subject: string, html: string) {
  const key = process.env.RESEND_API_KEY;
  if (!key || !to) return;
  try {
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from: process.env.EMAIL_FROM || "Loafchef <onboarding@resend.dev>", to, subject, html })
    });
  } catch (e) {
    console.error("Email failed", e);
  }
}
