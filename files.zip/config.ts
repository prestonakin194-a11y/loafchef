// Edit these to match how Loafchef actually runs.
export const SHOP = {
  name: "Loafchef",
  tagline: "Small-batch bread, pastry & cakes",
  address: "123 Baker Street, Your City",
  phone: "(555) 123-4567",
  email: "hello@loafchef.com",
  instagram: "@loafchef",
  hours: "Tue–Sun · 8am–5pm (closed Mondays)",
  openDays: [0, 2, 3, 4, 5, 6], // 0=Sun ... 6=Sat. Monday (1) closed
  slots: ["08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00"],
  slotCapacity: 5,        // max orders per time slot
  minDaysAhead: 1,        // earliest order date = tomorrow
  maxDaysAhead: 14,
  deliveryFee: 600,       // cents
  deliveryMin: 3000,      // cents, minimum subtotal for delivery
  customLeadDays: 3       // custom cake/catering needs this much notice
};

export const money = (cents: number) => `$${(cents / 100).toFixed(2)}`;

export function slotLabel(s: string) {
  const [h, m] = s.split(":").map(Number);
  return `${h % 12 || 12}:${String(m).padStart(2, "0")} ${h >= 12 ? "PM" : "AM"}`;
}
