import type { Metadata } from "next";
import "./globals.css";
import { CartProvider } from "@/components/CartContext";
import Nav from "@/components/Nav";
import { SHOP } from "@/lib/config";

export const metadata: Metadata = {
  title: `${SHOP.name} — ${SHOP.tagline}`,
  description: `Order fresh bread, pastries and cakes from ${SHOP.name} for pickup or delivery.`
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-sans">
        <CartProvider>
          <Nav />
          {children}
          <footer className="bg-crust text-flour py-12 mt-16">
            <div className="max-w-5xl mx-auto px-6 grid gap-8 md:grid-cols-3">
              <div>
                <div className="font-serif text-xl mb-2">{SHOP.name}<span className="text-ember">.</span></div>
                <p className="opacity-70 text-sm max-w-xs">{SHOP.tagline}.</p>
              </div>
              <div className="text-sm opacity-80 space-y-1">
                <div>{SHOP.address}</div>
                <div>{SHOP.hours}</div>
                <div>{SHOP.phone}</div>
              </div>
              <div className="text-sm opacity-80 space-y-1">
                <a href={`mailto:${SHOP.email}`} className="block hover:opacity-100">{SHOP.email}</a>
                <div>{SHOP.instagram}</div>
              </div>
            </div>
            <div className="max-w-5xl mx-auto px-6 border-t border-white/10 mt-8 pt-4 text-xs opacity-50">
              © {new Date().getFullYear()} {SHOP.name}.
            </div>
          </footer>
        </CartProvider>
      </body>
    </html>
  );
}
