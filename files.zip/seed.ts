import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

const products = [
  ["Country Sourdough", "Loaves", "Long-fermented, blistered crust, open crumb. 900g.", 900, "🍞"],
  ["Seeded Multigrain", "Loaves", "Sunflower, flax and sesame in a soft, nutty loaf.", 1000, "🌾"],
  ["Rosemary Focaccia", "Loaves", "Olive oil, flaky salt, fresh rosemary. Serves 4.", 1100, "🫒"],
  ["Cinnamon Raisin Loaf", "Loaves", "Swirled and sticky, made for toast.", 1000, "🥖"],
  ["Butter Croissant", "Pastries", "Laminated for three days. Shatteringly crisp.", 450, "🥐"],
  ["Pain au Chocolat", "Pastries", "Two bars of dark chocolate, buttery layers.", 500, "🍫"],
  ["Almond Danish", "Pastries", "Frangipane, toasted almonds, apricot glaze.", 550, "🥧"],
  ["Cardamom Bun", "Pastries", "Soft knot with cardamom sugar and pearl sugar top.", 450, "🌀"],
  ["Brown Butter Cookie", "Cookies", "Chewy, salted, with dark chocolate chunks.", 350, "🍪"],
  ["Oatmeal Cookie", "Cookies", "Oats, cinnamon and plump raisins.", 325, "🍪"],
  ["Lemon Loaf Cake", "Cakes", "Bright lemon crumb with a sugar glaze. Serves 8.", 2200, "🍋"],
  ["Chocolate Layer Cake (6\")", "Cakes", "Three layers, whipped ganache. Serves 8-10.", 4800, "🎂"]
] as const;

async function main() {
  if ((await prisma.product.count()) === 0) {
    for (const [name, category, description, price, emoji] of products) {
      await prisma.product.create({ data: { name, category, description, price, emoji } });
    }
  }
  console.log("Seeded placeholder menu. Replace with real items in /admin/products.");
}
main().finally(() => prisma.$disconnect());
