"use client";
import { useState } from "react";
import { submitQuote, setRequestStatus } from "@/app/admin/actions";

export default function QuoteForm({ id, quote, quoteNote }: { id: string; quote: number | null; quoteNote: string | null }) {
  const [amount, setAmount] = useState(quote ? (quote / 100).toFixed(2) : "");
  const [note, setNote] = useState(quoteNote || "");
  const [saved, setSaved] = useState(false);

  return (
    <div className="mt-3 pt-3 border-t border-line flex flex-wrap items-end gap-3">
      <div>
        <label className="block text-xs opacity-60 mb-1">Quote ($)</label>
        <input value={amount} onChange={(e) => setAmount(e.target.value)} className="w-28 border border-line p-2 text-sm bg-transparent" />
      </div>
      <div className="flex-1 min-w-[160px]">
        <label className="block text-xs opacity-60 mb-1">Note to customer</label>
        <input value={note} onChange={(e) => setNote(e.target.value)} className="w-full border border-line p-2 text-sm bg-transparent" />
      </div>
      <button
        onClick={async () => { await submitQuote(id, amount, note); setSaved(true); setTimeout(() => setSaved(false), 1500); }}
        className="bg-crust text-flour px-4 py-2 text-sm rounded-sm"
      >
        {saved ? "Saved ✓" : "Send quote"}
      </button>
      <select defaultValue="" onChange={(e) => e.target.value && setRequestStatus(id, e.target.value)} className="border border-line p-2 text-sm bg-transparent">
        <option value="">Set status…</option>
        <option value="ACCEPTED">Accepted</option>
        <option value="DECLINED">Declined</option>
      </select>
    </div>
  );
}
