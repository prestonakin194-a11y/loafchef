# Loafchef

A real Next.js bakery site: browse the menu, order for pickup or delivery with live
time-slot availability, request custom cakes/catering, and manage all of it from a
password-protected baker dashboard.

## Stack
- **Next.js 14** (App Router, TypeScript, Server Actions)
- **Prisma** — SQLite for local dev, swap to Postgres for production
- **Stripe Checkout** for payments
- **Tailwind CSS**
- Optional email receipts via **Resend**

## First, replace the placeholder content

Everything in the code right now is a placeholder so the site runs immediately. Before
launch, update:

- `lib/config.ts` — shop name, address, phone, hours, delivery fee/minimum, slot times
  and capacity, how many days ahead people can order, custom-order lead time
- `app/about/page.tsx` — your actual story
- The seeded menu in `prisma/seed.ts`, **or** just edit items directly in
  `/admin/products` once it's running — that's the easier way
- Logo/colors: current palette and type pairing live in `tailwind.config.ts` and
  `app/globals.css`

## Run it locally

```bash
npm install
cp .env.example .env
npx prisma migrate dev --name init
npm run seed
npm run dev
```

Open http://localhost:3000. Set `ADMIN_PASSWORD` in `.env` first, then sign in at
**/admin/login** to reach the baker dashboard (orders, menu, custom requests).

## Setting up Stripe (test mode, free)

1. Create a free [Stripe account](https://dashboard.stripe.com/register).
2. Copy your **test** secret key from
   [dashboard.stripe.com/test/apikeys](https://dashboard.stripe.com/test/apikeys) into
   `.env` as `STRIPE_SECRET_KEY`.
3. Install the [Stripe CLI](https://docs.stripe.com/stripe-cli), then with `npm run dev`
   running, in a second terminal:
   ```bash
   stripe listen --forward-to localhost:3000/api/webhooks/stripe
   ```
   Copy the printed `whsec_...` into `.env` as `STRIPE_WEBHOOK_SECRET`, restart `npm run dev`.
4. Order something and pay with test card `4242 4242 4242 4242`, any future expiry/CVC.
5. It'll show as paid in `/admin` immediately.

## Optional: order/request emails

Sign up for a free [Resend](https://resend.com) account, put the API key in `.env` as
`RESEND_API_KEY`, and set `OWNER_EMAIL` to where you want new-order and new-request
notifications sent. Leave both blank and the site works fine without emails.

## Deploying to your own domain (Vercel)

SQLite's file doesn't persist on serverless hosting, so for production:

1. Get a free hosted Postgres DB — [Neon](https://neon.tech) is the easiest.
2. In `prisma/schema.prisma`, change `provider = "sqlite"` to `provider = "postgresql"`.
3. Push this repo to GitHub, import it into Vercel.
4. In Vercel's Environment Variables, set everything from `.env.example`:
   `DATABASE_URL` (your Neon connection string), `NEXT_PUBLIC_APP_URL` (your real
   domain), `ADMIN_PASSWORD`, `ADMIN_SECRET`, `STRIPE_SECRET_KEY` (switch to your live
   key when ready), `STRIPE_WEBHOOK_SECRET` (from a webhook endpoint you add in the
   Stripe dashboard pointed at `https://yourdomain.com/api/webhooks/stripe`, listening
   for `checkout.session.completed` and `checkout.session.expired`), and the Resend
   variables if you're using email.
5. After first deploy, run once from your machine pointed at the prod `DATABASE_URL`:
   ```bash
   npx prisma migrate deploy
   npm run seed
   ```
6. Point your domain at the Vercel project.

## What's real vs. still a demo
- ✅ Live menu, editable from `/admin/products` — sold-out toggles instantly hide items
- ✅ Real time-slot booking with a daily capacity limit, enforced server-side (prices
  and slot availability are always re-checked at checkout, never trusted from the browser)
- ✅ Real Stripe payment, webhook-confirmed, admin dashboard shows every paid order
- ✅ Custom cake/catering requests with a quoting workflow
- ⚠️ Single shared admin password — fine for one baker; add per-user accounts if more
  than one person needs their own login
- ⚠️ No SMS notifications, no loyalty/rewards, no multi-location support
- ⚠️ Guest checkout only — no customer accounts or order history lookup
