"use client";
import { updateOrderStatus } from "@/app/admin/actions";

const STATUSES = ["PENDING", "CONFIRMED", "READY", "COMPLETED", "CANCELLED"];

export default function OrderStatusSelect({ orderId, status }: { orderId: string; status: string }) {
  return (
    <select
      defaultValue={status}
      onChange={(e) => updateOrderStatus(orderId, e.target.value)}
      className="border border-line p-2 text-sm bg-transparent"
    >
      {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
    </select>
  );
}
