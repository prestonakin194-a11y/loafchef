import { prisma } from "./prisma";
import { sendEmail } from "./email";
import { money, slotLabel, SHOP } from "./config";

// Marks an order paid + confirmed (idempotent) and emails the customer once.
export async function confirmOrder(orderId: string) {
  const res = await prisma.order.updateMany({
    where: { id: orderId, paymentStatus: "UNPAID" },
    data: { paymentStatus: "PAID", status: "CONFIRMED" }
  });
  if (res.count === 0) return; // already confirmed
  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { items: true } });
  if (!order) return;
  const lines = order.items.map((i) => `<li>${i.qty} × ${i.name}</li>`).join("");
  const where = order.fulfillment === "DELIVERY" ? `Delivery to ${order.address}` : `Pickup at ${SHOP.address}`;
  await sendEmail(order.email, `Your ${SHOP.name} order is confirmed`,
    `<p>Hi ${order.name}, thanks for your order!</p><ul>${lines}</ul>
     <p><b>${where}</b><br/>${order.date} at ${slotLabel(order.slot)}</p><p>Total paid: ${money(order.total)}</p>`);
  if (process.env.OWNER_EMAIL) {
    await sendEmail(process.env.OWNER_EMAIL, `New order: ${order.name} (${order.date} ${slotLabel(order.slot)})`,
      `<ul>${lines}</ul><p>${order.fulfillment} · ${money(order.total)}</p>`);
  }
}
